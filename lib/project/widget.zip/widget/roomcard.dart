import 'package:flutter/material.dart';

enum TimeSlotState { free, reserved, pending, disabled }

class Roomcard extends StatefulWidget {
  final String name, image;
  final int roomId, size, timeSlot1, timeSlot2, timeSlot3, timeSlot4;

  const Roomcard(
      {super.key,
      required this.roomId,
      required this.name,
      required this.size,
      required this.image,
      required this.timeSlot1,
      required this.timeSlot2,
      required this.timeSlot3,
      required this.timeSlot4});
  @override
  State<Roomcard> createState() => _RoomcardState();
}

class _RoomcardState extends State<Roomcard> {
  // Request alert dialog for student
  void reqAlert(String roomName, String timeSlot) async {
    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Student request'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                'assets/images/TableLargeRoom.png',
                width: 150,
                height: 100,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Room Name: $roomName'),
                  Text('Time slot: $timeSlot'),
                  const Text('Room Size: Large size (20 people)'),
                  const Text('Date: xx/xx/xxxx'),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, 'Submit'),
              style: ButtonStyle(
                backgroundColor: WidgetStateProperty.all<Color>(Colors.green),
                foregroundColor: WidgetStateProperty.all<Color>(Colors.white),
              ),
              child: const Text('Submit'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, 'Cancel'),
              style: ButtonStyle(
                backgroundColor: WidgetStateProperty.all<Color>(Colors.red),
                foregroundColor: WidgetStateProperty.all<Color>(Colors.white),
              ),
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  // Method to map slot status to TimeSlotState
  TimeSlotState _getTimeSlotState(int status) {
    switch (status) {
      case 1:
        return TimeSlotState.free;
      case 4:
        return TimeSlotState.reserved;
      case 2:
        return TimeSlotState.pending;
      default:
        return TimeSlotState.disabled;
    }
  }

  Widget _buildTimeSlotRow(String time, int slotStatus) {
    TimeSlotState state = _getTimeSlotState(slotStatus);

    Color buttonColor;
    String buttonText;

    switch (state) {
      case TimeSlotState.free:
        buttonColor = Colors.green[700]!;
        buttonText = "free";
        break;
      case TimeSlotState.reserved:
        buttonColor = Colors.grey[700]!;
        buttonText = "reserved";
        break;
      case TimeSlotState.pending:
        buttonColor = Colors.amber[700]!;
        buttonText = "pending";
        break;
      case TimeSlotState.disabled:
      default:
        buttonColor = Colors.red[700]!;
        buttonText = "disabled";
        break;
    }

    //btn
    return Row(
      children: [
        Text(time),
        const SizedBox(width: 5),
        SizedBox(
          width: 80,
          height: 30,
          child: FilledButton(
            onPressed: state == TimeSlotState
                ? null
                : () {
                    if (state == TimeSlotState.free) {
                      reqAlert(widget.name, time);
                    }
                  },
            style: ButtonStyle(
              backgroundColor: WidgetStateProperty.all(buttonColor),
              padding: WidgetStateProperty.all(
                  const EdgeInsets.only(right: 8, left: 8)),
            ),
            child:
                Text(buttonText, style: const TextStyle(color: Colors.white)),
          ),
        ),
      ],
    );
  }

  //card
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 9,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            Expanded(
              flex: 1,
              child: Padding(
                padding: const EdgeInsets.only(right: 5, left: 5, top: 10),
                child: Column(
                  children: [
                    Container(
                        child: Image.network(
                      "http://172.23.96.1:3000/public/images/${widget.image}",
                      fit: BoxFit.cover,
                    )),
                    Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: Text(widget.name),
                    ),
                    Builder(builder: (context) {
                      switch (widget.size) {
                        case 1:
                          return Text('Small size(5 People)');
                        case 2:
                          return Text('Medium size(10 People)');
                        default:
                          return Text('large size(20 People)');
                      }
                    }),
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 1,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 20, top: 5),
                    child: _buildTimeSlotRow('08:00-10:00', widget.timeSlot1),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 20, top: 5),
                    child: _buildTimeSlotRow('10:00-12:00', widget.timeSlot2),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 20, top: 5),
                    child: _buildTimeSlotRow('13:00-15:00', widget.timeSlot3),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 20, top: 5),
                    child: _buildTimeSlotRow('15:00-17:00', widget.timeSlot4),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}